// -- Get HTML Refrences -- \\
const nav = document.querySelector('.nav');

// -- Scrolling -- \\
let y = window.scrollY;

window.addEventListener('scroll', () => {
  if (y < window.scrollY) {
    nav.classList.add('nav-hide');
  } else {
    nav.classList.remove('nav-hide');
  }

  y = window.scrollY;
});
